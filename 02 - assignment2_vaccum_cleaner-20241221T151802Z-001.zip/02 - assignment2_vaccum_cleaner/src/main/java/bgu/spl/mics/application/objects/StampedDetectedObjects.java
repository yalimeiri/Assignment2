package bgu.spl.mics.application.objects;

/**
 * Represents objects detected by the camera at a specific timestamp.
 * Includes the time of detection and a list of detected objects.
 */
public class StampedDetectedObjects {
    // TODO: Define fields and methods.
}
